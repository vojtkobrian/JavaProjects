// Program:	Book.java
// Purpose: This program simulates a bookstore catalog.
// Author:	Brian Vojtko	
// Date:	12/4/2018
package HW8;
public class Book {

	private String bookCode;
	private String bookTitle;
	private String bookWriter;
	private int numofPages;
	private double bookPrice;
	private int quantity;
	private int sold;
	
	//Book Constructor
	public Book(String code, String title, String author, int pages, double price, int qty, int qtyLeft)
	{
		bookCode=code;
		bookTitle=title;
		bookWriter=author;
		numofPages=pages;
		bookPrice=price;
		quantity=qty;
		sold=(quantity-=sold);
	}
	//Returns Book's Title
	public String getTitle() 
	{
		return bookTitle;
	}
	//Returns Author
	public String getAuthor()
	{
		return bookWriter;
	}
	//Returns ISBN
	public String getCode()
	{
		return bookCode;
	}
	//Returns Number of Pages
	public int getPages() 
	{
		return numofPages;
	}
	//Returns Price
	public double getPrice()
	{
		return bookPrice;
	}
	//Returns Quantity
	public int getQty() 
	{
		return quantity;
	}
	//Returns Sold
	public int getSold()
	{
		return sold;
	}
	//Sets Books Title
	public void setTitle(String t)
	{
		bookTitle=t;
	}
	//Sets Author
	public void setAuthor(String a)
	{
		bookWriter=a;
	}
	//Sets ISBN
	public void setCode(String c)
	{
		bookCode=c;
	}
	//Sets Number of Pages
	public void setPages(int p)
	{
		numofPages=p;
	}
	//Sets Price
	public void setPrice(double pr)
	{
		bookPrice=pr;
	}
	//Sets Quantity
	public void setQty(int q)
	{
		quantity=q;
	}
	//Sets Sold
	public void setSold(int s)
	{
		sold=s;
	}

	public String toString()
	{
		return bookCode+"\t\t"+bookTitle+"\t\t\t"+bookWriter+"\t\t"+numofPages+"\t\t"+bookPrice+"\t\t"+quantity+"\n";
	}
	public String soldBook()
	{
		return bookCode+"\t\t"+bookTitle+"\t\t\t"+bookWriter+"\t\t"+numofPages+"\t\t"+bookPrice+"\t\t"+sold+"\n";
	}
}